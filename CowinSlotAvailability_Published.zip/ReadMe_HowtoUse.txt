1. Open "CowinSlotAvailability.exe.config" with notepad or notepad++
2. Made the required changes like To Email ID, From Gmail Id, From Gmail Id password.
3. Respective District ID you can find on MappingDistrict.CSV
4. Once you made the required changes on config save them and double click on CowinSlotAvailability.exe
5. IF you want to run this application for a long run, update config key apiHitIterations value to large value but not more than value 2147483647

NOTE: 
1. Currently this utility supports only gmail id to send email.
2. If Gmail throws security error during sending email Goto 

https://myaccount.google.com/lesssecureapps
and Set Allow less secure apps: ON 